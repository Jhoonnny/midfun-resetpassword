"""BD URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from django.urls import path

from .views import inicio,InicioSesion,metaspagina,login,logout,register,registro,registrar,meta,perfil,password_reset, password_reset_done,password_reset_confirm, password_reset_complete

urlpatterns = [
    path('', inicio,name='inicio'),
    path('inicio.html', inicio,name='inicio'),
    path('InicioSesion.html', login,name='InicioSesion'),
    path('Registro.html', registro,name='registro'),
    path('register', register,name='register'),
    path('Metas.html', metaspagina,name='metas'),
    path('inicioSesion.html', logout ,name='cerrar'),
    path('registrar', registrar, name='registro2'),
    path('metas', meta, name='metasg'),
    path('perfil', perfil, name='perfil'),
    #path('regis/password_reset_form.html', password_reset, name='password_reset'),
    #path('regis/password_reset_done.html', password_reset_done, name='password_reset_done'),
    #path('regis/password_reset_confirm.html', password_reset_confirm, name='password_reset_confirm'),
    #path('regis/password_reset_complete.html', password_reset_complete, name='password_reset_complete')
    url(r'^reset/password_reset', password_reset, {template_name='regis/password_reset_form.html',
        'email_template_name':'regis/password_reset_email.html'}, name='password_reset'),
    
    url(r'^reset/password_reset_done', password_reset_done, 
       {template_name:'regis/password_reset_done.html'}, name='password_reset_done'),
    
    url(r'^reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>.+)/$', password_reset_confirm, {template_name:'regis/password_reset_confirm.html'},
    name='password_reset_confirm'
    ),

    url(r'^reset/done', password_reset_complete, {'template_name':'regis/password_reset_complete.html'},
    name='password_reset_complete'
    )




    
    
]




